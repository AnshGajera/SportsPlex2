import React from 'react';

const UserManagementTest = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>User Management Test</h1>
      <p>This is a simple test component to check if the route works.</p>
    </div>
  );
};

export default UserManagementTest;
