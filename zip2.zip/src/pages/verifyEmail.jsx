
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, sendVerificationEmail, resendVerificationEmail, checkEmailVerification } from '../firebase/config';

const VerifyEmail = () => {
  const navigate = useNavigate();
  const [emailSent, setEmailSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);

  // Send verification email only once on mount if needed
  useEffect(() => {
    const user = auth.currentUser;
    console.log('Current user in verifyEmail:', user);
    
    if (user && !user.emailVerified && !emailSent) {
      sendInitialVerificationEmail(user);
    } else if (!user) {
      console.error('No authenticated user found.');
      navigate('/login');
    }
    // eslint-disable-next-line
  }, [emailSent, navigate]);

  const sendInitialVerificationEmail = async (user) => {
    setLoading(true);
    setError('');
    
    const result = await sendVerificationEmail(user);
    
    if (result.success) {
      setEmailSent(true);
      console.log('Verification email sent!');
    } else {
      setError(result.error);
      console.error('Email sending failed:', result.error);
    }
    
    setLoading(false);
  };

  // Poll for verification status
  useEffect(() => {
    const interval = setInterval(async () => {
      const result = await checkEmailVerification();
      
      if (result.success && result.isVerified) {
        // Update backend about verification status
        try {
          await fetch('/api/auth/verify-email', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              email: result.user.email,
              firebaseUid: result.user.uid,
            }),
          });
          clearInterval(interval);
          navigate('/Home');
        } catch (error) {
          console.error('Error updating verification status:', error);
          // Navigate anyway since email is verified
          clearInterval(interval);
          navigate('/Home');
        }
      }
    }, 3000);
    return () => clearInterval(interval);
  }, [navigate]);

  const resendVerification = async () => {
    if (resendCooldown > 0) {
      setError(`Please wait ${resendCooldown} seconds before resending.`);
      return;
    }

    setLoading(true);
    setError('');
    
    const result = await resendVerificationEmail();
    
    if (result.success) {
      setEmailSent(true);
      setResendCooldown(60); // 60 second cooldown
      
      // Start cooldown timer
      const cooldownInterval = setInterval(() => {
        setResendCooldown((prev) => {
          if (prev <= 1) {
            clearInterval(cooldownInterval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      setError(''); // Clear any previous errors
    } else {
      setError(result.error);
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Please Verify Your Email</h1>
          <p className="mt-2 text-sm text-gray-600">
            Check your inbox or spam folder: 
            <span className="font-medium text-blue-600 block">
              {auth.currentUser?.email}
            </span>
          </p>
        </div>

        <div className="bg-white shadow-lg rounded-lg p-6 space-y-4">
          {error && (
            <div className="p-4 border border-red-300 rounded-md bg-red-50">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              </div>
            </div>
          )}

          {emailSent && !error && (
            <div className="p-4 border border-green-300 rounded-md bg-green-50">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-green-800">
                    Verification email sent! Please check your inbox and spam folder.
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="text-center">
            <p className="text-sm text-gray-600 mb-4">
              Click the verification link in your email to continue. The page will automatically refresh once verified.
            </p>
            
            <div className="flex items-center justify-center space-x-2 text-sm text-gray-500 mb-4">
              <div className="animate-pulse flex space-x-1">
                <div className="h-2 w-2 bg-blue-600 rounded-full animate-bounce"></div>
                <div className="h-2 w-2 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                <div className="h-2 w-2 bg-blue-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
              </div>
              <span>Checking verification status...</span>
            </div>
          </div>

          <button
            onClick={resendVerification}
            disabled={resendCooldown > 0 || loading}
            className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white 
              ${resendCooldown > 0 || loading 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
              } transition-colors duration-200`}
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Sending...
              </>
            ) : resendCooldown > 0 ? (
              `Resend in ${resendCooldown}s`
            ) : (
              'Resend Email'
            )}
          </button>

          <div className="text-center">
            <button
              onClick={() => navigate('/login')}
              className="text-sm text-blue-600 hover:text-blue-500 font-medium"
            >
              Back to login
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-gray-500">
                    You'll be redirected once verified. Didn't receive the email? Check your spam folder.
        </p>
      </div>
    </div>
  );
};

export default VerifyEmail;
        </p>
      </div>
    </div>
  );mport { auth, sendVerificationEmail, resendVerificationEmail, checkEmailVerification } from '../firebase/config'; // adjust the path if the file is in config.js

const VerifyEmail = () => {
  const navigate = useNavigate();
  const [emailSent, setEmailSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);

  // Send verification email only once on mount if needed
  useEffect(() => {
    const user = auth.currentUser;
    console.log('Current user in verifyEmail:', user);
    
    if (user && !user.emailVerified && !emailSent) {
      sendInitialVerificationEmail(user);
    } else if (!user) {
      console.error('No authenticated user found.');
      navigate('/login');
    }
    // eslint-disable-next-line
  }, [emailSent, navigate]);

  const sendInitialVerificationEmail = async (user) => {
    setLoading(true);
    setError('');
    
    const result = await sendVerificationEmail(user);
    
    if (result.success) {
      setEmailSent(true);
      console.log('Verification email sent!');
    } else {
      setError(result.error);
      console.error('Email sending failed:', result.error);
    }
    
    setLoading(false);
  };

  // Poll for verification status
  useEffect(() => {
    const interval = setInterval(async () => {
      const result = await checkEmailVerification();
      
      if (result.success && result.isVerified) {
        // Update backend about verification status
        try {
          await fetch('/api/auth/verify-email', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              email: result.user.email,
              firebaseUid: result.user.uid,
            }),
          });
          clearInterval(interval);
          navigate('/Home');
        } catch (error) {
          console.error('Error updating verification status:', error);
          // Navigate anyway since email is verified
          clearInterval(interval);
          navigate('/Home');
        }
      }
    }, 3000);
    return () => clearInterval(interval);
  }, [navigate]);

  const resendVerification = async () => {
    if (resendCooldown > 0) {
      setError(`Please wait ${resendCooldown} seconds before resending.`);
      return;
    }

    setLoading(true);
    setError('');
    
    const result = await resendVerificationEmail();
    
    if (result.success) {
      setEmailSent(true);
      setResendCooldown(60); // 60 second cooldown
      
      // Start cooldown timer
      const cooldownInterval = setInterval(() => {
        setResendCooldown((prev) => {
          if (prev <= 1) {
            clearInterval(cooldownInterval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      setError(''); // Clear any previous errors
    } else {
      setError(result.error);
    }
    
    setLoading(false);
  };

  return (
    <div className="text-center mt-10">
      <h1 className="text-2xl font-bold">Please Verify Your Email</h1>
      <p className="mt-2">Check your inbox or spam folder: {auth.currentUser?.email}</p>
      <button
        onClick={resendVerification}
        className="mt-4 px-4 py-2 bg-blue-600 text-white rounded"
      >
        Resend Email
      </button>
      <p className="mt-2 text-sm text-gray-500">You’ll be redirected once verified...</p>
    </div>
  );
};

export default VerifyEmail;
