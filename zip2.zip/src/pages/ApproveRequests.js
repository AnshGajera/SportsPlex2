import React from 'react';

const ApproveRequests = () => {
  return (
    <div className="container" style={{ padding: '32px 20px' }}>
      <h1 className="page-title">Approve Equipment Requests</h1>
      <p className="page-subtitle">Review and approve equipment requests from users.</p>
      {/* Add request approval content here */}
    </div>
  );
};

export default ApproveRequests;
